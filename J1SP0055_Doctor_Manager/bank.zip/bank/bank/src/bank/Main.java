/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank;

import static bank.Bank.checkMenu;
import static bank.Bank.login;
import static bank.Bank.menu;
import java.util.Locale;

/**
 *
 * @author Admin
 */
public class Main {
    public static void main(String[] args) {
        // TODO code application logic here
        
        Locale vn = new Locale("vn", "VN");
        Locale en = Locale.US;
        menu();
        int choice = checkMenu(1, 3);
        switch (choice) {
            case 1:
                login(vn);
                break;
            case 2:
                login(en);
            case 3:
                break;
        }
    }
}
