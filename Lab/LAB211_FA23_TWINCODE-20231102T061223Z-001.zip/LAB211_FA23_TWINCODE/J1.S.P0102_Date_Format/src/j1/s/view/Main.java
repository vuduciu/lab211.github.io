package j1.s.view;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.excute();
    }
}
